<?php
class Quick_Notes_Deactivator {
    public static function deactivate() {
        // Actions to perform on plugin deactivation, such as cleanup tasks.
    }
}